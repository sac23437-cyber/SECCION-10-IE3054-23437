/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define VUELTAS_MAX 3  // Número de vueltas necesarias para ganar
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint8_t contadorJ1 = 0x01;  // 0000 0001
uint8_t contadorJ2 = 0x01;  // 0000 0001
uint8_t vueltasJ1 = 0;      // contador de vueltas jugador 1
uint8_t vueltasJ2 = 0;      // contador de vueltas jugador 2
uint8_t carreraIniciada = 0;
uint8_t ganador = 0;        // 0 = ninguno, 1 = jugador1, 2 = jugador2
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
void mostrarContadorJ1(uint8_t valor);
void mostrarContadorJ2(uint8_t valor);
void secuenciaSemaforo(void);
void chequearGanador(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void mostrarContadorJ1(uint8_t valor) {
    // Apagar todos los LEDs de J1 + LED de meta
    HAL_GPIO_WritePin(GPIOC, J1_1_Pin|J1_2_Pin|J1_3_Pin|J1_4_Pin|
                             J1_7_Pin|J1_8_Pin|J1W_Pin|GPIO_PIN_5|
                             GPIO_PIN_10|GPIO_PIN_15, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, J1_5_Pin|J1_6_Pin, GPIO_PIN_RESET);

    // Encendido según valor
    if (valor & 0x01) HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);
    if (valor & 0x02) HAL_GPIO_WritePin(GPIOC, J1_2_Pin, GPIO_PIN_SET);
    if (valor & 0x04) HAL_GPIO_WritePin(GPIOC, J1_3_Pin, GPIO_PIN_SET);
    if (valor & 0x08) HAL_GPIO_WritePin(GPIOC, J1_4_Pin, GPIO_PIN_SET);
    if (valor & 0x10) HAL_GPIO_WritePin(GPIOB, J1_5_Pin, GPIO_PIN_SET);
    if (valor & 0x20) HAL_GPIO_WritePin(GPIOB, J1_6_Pin, GPIO_PIN_SET);
    if (valor & 0x40) HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, GPIO_PIN_SET);
    if (valor & 0x80) {
        HAL_GPIO_WritePin(J1_8_GPIO_Port, J1_8_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, GPIO_PIN_SET); // LED de meta
    }
}

void mostrarContadorJ2(uint8_t valor) {
    // Apagar todos los LEDs de J2 + LED de meta
    HAL_GPIO_WritePin(GPIOA, J2_1_Pin|J2_2_Pin|J2_3_Pin|J2_4_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, J2_5_Pin|J2_6_Pin|J2_7_Pin|J2_8_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); // LED de meta

    // Encendido según valor
    if (valor & 0x01) HAL_GPIO_WritePin(GPIOA, J2_1_Pin, GPIO_PIN_SET);
    if (valor & 0x02) HAL_GPIO_WritePin(GPIOA, J2_2_Pin, GPIO_PIN_SET);
    if (valor & 0x04) HAL_GPIO_WritePin(GPIOA, J2_3_Pin, GPIO_PIN_SET);
    if (valor & 0x08) HAL_GPIO_WritePin(GPIOA, J2_4_Pin, GPIO_PIN_SET);
    if (valor & 0x10) HAL_GPIO_WritePin(GPIOB, J2_5_Pin, GPIO_PIN_SET);
    if (valor & 0x20) HAL_GPIO_WritePin(GPIOB, J2_6_Pin, GPIO_PIN_SET);
    if (valor & 0x40) HAL_GPIO_WritePin(GPIOB, J2_7_Pin, GPIO_PIN_SET);
    if (valor & 0x80) {
        HAL_GPIO_WritePin(GPIOB, J2_8_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); // LED de meta
    }
}

void secuenciaSemaforo(void) {
  // Apagar todos los LEDs de los jugadores al inicio
  mostrarContadorJ1(0x00);
  mostrarContadorJ2(0x00);

  // Asegura que estén apagados
  HAL_GPIO_WritePin(GPIOA, Red_Pin|Yellow_Pin|Green_Pin, GPIO_PIN_RESET);
  HAL_Delay(200);

  // Rojo
  HAL_GPIO_WritePin(GPIOA, Red_Pin, GPIO_PIN_SET);
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOA, Red_Pin, GPIO_PIN_RESET);
  HAL_Delay(200);

  // Amarillo
  HAL_GPIO_WritePin(GPIOA, Yellow_Pin, GPIO_PIN_SET);
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOA, Yellow_Pin, GPIO_PIN_RESET);
  HAL_Delay(200);

  // Verde
  HAL_GPIO_WritePin(GPIOA, Green_Pin, GPIO_PIN_SET);
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOA, Green_Pin, GPIO_PIN_RESET);

  // Inicia la "carrera"
  carreraIniciada = 1;

  // Inicializar los contadores y vueltas al inicio de la carrera
  contadorJ1 = 0x01;
  contadorJ2 = 0x01;
  vueltasJ1 = 0;
  vueltasJ2 = 0;
  ganador = 0;

  // Mostrar el primer estado de los jugadores
  mostrarContadorJ1(contadorJ1);
  mostrarContadorJ2(contadorJ2);
}

// Nueva función: revisar si algún jugador completó las vueltas
void chequearGanador(void) {
    if (ganador != 0) return;

    // Revisar jugador 1
    if (contadorJ1 == 0x80) {
        vueltasJ1++;
        contadorJ1 = 0x00; // usar 0x00 para reinicio y que el siguiente botón sea 0x01
    }

    // Revisar jugador 2
    if (contadorJ2 == 0x80) {
        vueltasJ2++;
        contadorJ2 = 0x00;
    }

    if (vueltasJ1 >= VUELTAS_MAX) {
        ganador = 1;
        carreraIniciada = 0;
        mostrarContadorJ1(0xFF);
    } else if (vueltasJ2 >= VUELTAS_MAX) {
        ganador = 2;
        carreraIniciada = 0;
        mostrarContadorJ2(0xFF);
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */
  // Mostrar estado inicial en las pistas
  mostrarContadorJ1(contadorJ1);
  mostrarContadorJ2(contadorJ2);
  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
      // Botón del semáforo (PC13)
      if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET) {
          HAL_Delay(50);
          if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET) {
              // Reiniciar contadores y vueltas
              contadorJ1 = 0x01;
              contadorJ2 = 0x01;
              vueltasJ1 = 0;
              vueltasJ2 = 0;
              ganador = 0;

              // Apagar todos los LEDs (incluyendo los de meta)
              mostrarContadorJ1(0x00);
              mostrarContadorJ2(0x00);

              carreraIniciada = 0;
              secuenciaSemaforo();
          }
      }

      if (carreraIniciada) {
          // Botón jugador 1 (PA0)
    	  if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET) {
    	      HAL_Delay(50);
    	      if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET) {
    	          if (contadorJ1 == 0x00) contadorJ1 = 0x01; // si reinició, iniciar desde el primer LED
    	          else contadorJ1 <<= 1;
    	          mostrarContadorJ1(contadorJ1);
    	          while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET);
    	      }
    	  }

          // Botón jugador 2 (PA8)
    	  if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == GPIO_PIN_RESET) { // botón J2
    	      HAL_Delay(50);
    	      if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == GPIO_PIN_RESET) {
    	          if(contadorJ2 == 0x00)
    	              contadorJ2 = 0x01; // si reinició, iniciar desde el primer LED
    	          else
    	              contadorJ2 <<= 1;
    	          mostrarContadorJ2(contadorJ2);
    	          while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == GPIO_PIN_RESET);
    	      }
    	  }

          // Revisar ganador después de cada acción
          chequearGanador();
      }

      HAL_Delay(10); // pequeño retardo para no sobrecargar el MCU
  }
} /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, J1_2_Pin|J1_3_Pin|J1_4_Pin|J1_1_Pin
                          |J2W_Pin|J1_7_Pin|J1W_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Red_Pin|Yellow_Pin|Green_Pin|J2_1_Pin
                          |J2_2_Pin|J2_3_Pin|J2_4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, J1_5_Pin|J2_5_Pin|J2_6_Pin|J2_7_Pin
                          |J2_8_Pin|J1_6_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : BS_Pin */
  GPIO_InitStruct.Pin = BS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : J1_2_Pin J1_3_Pin J1_4_Pin J1_1_Pin
                           J2W_Pin J1_7_Pin J1W_Pin */
  GPIO_InitStruct.Pin = J1_2_Pin|J1_3_Pin|J1_4_Pin|J1_1_Pin
                          |J2W_Pin|J1_7_Pin|J1W_Pin
						  |GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : B1_Pin B2_Pin */
  GPIO_InitStruct.Pin = B1_Pin|B2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Red_Pin Yellow_Pin Green_Pin J2_1_Pin
                           J2_2_Pin J2_3_Pin J2_4_Pin */
  GPIO_InitStruct.Pin = Red_Pin|Yellow_Pin|Green_Pin|J2_1_Pin
                          |J2_2_Pin|J2_3_Pin|J2_4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : J1_5_Pin J2_5_Pin J2_6_Pin J2_7_Pin
                           J2_8_Pin J1_6_Pin */
  GPIO_InitStruct.Pin = J1_5_Pin|J2_5_Pin|J2_6_Pin|J2_7_Pin
                          |J2_8_Pin|J1_6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : J1_8_Pin */
  GPIO_InitStruct.Pin = J1_8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; // ✅ Salida push-pull
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(J1_8_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
