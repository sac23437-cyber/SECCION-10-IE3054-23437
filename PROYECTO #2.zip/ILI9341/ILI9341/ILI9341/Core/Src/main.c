/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body simplificado
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "fatfs_sd.h"
#include "string.h"
#include "stdio.h"
#include "ili9341.h"
#include "bitmaps.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "colisiones.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
SPI_HandleTypeDef hspi1;
FATFS fs;
FATFS *pfs;
FIL fil;
FRESULT fres;
DWORD fre_clust;
uint32_t totalSpace, freeSpace;
char buffer[100];

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
typedef enum {
    PANTALLA_MENU,
    PANTALLA_NIVELES,
    PANTALLA_NIVEL1
} Pantalla;

#define DEADZONE 100
#define MAX_ANALOG 4095
#define CENTER 1850

#define EN_SUELO 0
#define SALTANDO 1
#define CAYENDO 2

SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart2;

// No usaremos los arrays en flash para fondos
// extern uint8_t fondo[];
// extern uint8_t niveles[];
// extern uint8_t nivel1[];
// extern uint8_t final[];

// Creamos punteros para fondos cargados desde SD
uint8_t *fondoSD = NULL;
uint8_t *nivelesSD = NULL;
uint8_t *nivel1SD = NULL;
uint8_t *finalSD = NULL;

// Personajes y animaciones siguen igual
extern uint8_t Fireboy[];
extern uint8_t Watergirl[];

extern uint8_t Fcaminando[];
extern uint8_t Wcaminando[];

extern uint8_t Fsalto[];
extern uint8_t Wsalto[];

extern uint8_t Fcaida[];
extern uint8_t Wcaida[];

extern uint8_t fuegoD[];
extern uint8_t aguaD[];

int x_F = 280, y_F = 31.5, vel_F = 0;
int x_W = 20, y_W = 128, vel_W = 0;

int direccionF = 1; // 1 = derecha, -1 = izquierda
int direccionW = 1; // 1 = derecha, -1 = izquierda

int xValue_F = CENTER;
int xValue_W = CENTER;

Pantalla pantalla_actual = PANTALLA_MENU;

typedef struct {
    char emisorID[5];
    int xValue;
    uint8_t botonState;
} struct_message;

struct_message datosRecibidos;

uint8_t rxByte;
char uartBuffer[64];
int uartIndex = 0;

int estadoF = EN_SUELO;
int estadoW = EN_SUELO;
int alturaMaximaF = 8;
int alturaMaximaW = 8;
int velocidadSaltoF = 5;
int velocidadSaltoW = 5;

uint8_t saltoF_Trigger = 0;
uint8_t saltoW_Trigger = 0;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART4_Init(void);
/* USER CODE BEGIN PFP */
void EnviarMensaje(char *msg);
int BotonPresionado(void);
void EsperarBotonSoltado(void);
void ProcesarEntrada(void);
void MoverSprites(void);
void MoverVertical(int *x, int *y, int ancho, int alto, int *estado, int *inicioSaltoY, int alturaMax, int velocidad);

void SystemClock_Config(void);
void MX_GPIO_Init(void);
void MX_SPI1_Init(void);
void MX_USART2_UART_Init(void);
void MX_UART4_Init(void);

/* USER CODE BEGIN PFP */
void DibujarDiamantes(void);
void VerificarRecoleccion(void);
void VerificarMuerte(void);
void VerificarFinal(void);

// ===============================
// Función para cargar fondos desde SD
// ===============================
uint8_t* CargarImagenSD(const char* filename, uint32_t size_bytes) {
    FIL file;
    FRESULT res;
    uint8_t *buffer = malloc(size_bytes);
    if (!buffer) {
        EnviarMensaje("Error: No hay memoria para el fondo SD\r\n");
        return NULL;
    }

    res = f_open(&file, filename, FA_READ);
    if (res != FR_OK) {
        EnviarMensaje("Error: no se pudo abrir archivo SD\r\n");
        free(buffer);
        return NULL;
    }

    UINT bytesLeidos;
    res = f_read(&file, buffer, size_bytes, &bytesLeidos);
    f_close(&file);

    if (res != FR_OK || bytesLeidos != size_bytes) {
        EnviarMensaje("Error: lectura incompleta de archivo SD\r\n");
        free(buffer);
        return NULL;
    }

    return buffer;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void EnviarMensaje(char *msg) {
    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

int BotonPresionado(void) {
    static uint8_t estadoAnterior = 1;
    uint8_t estadoActual = HAL_GPIO_ReadPin(BS_GPIO_Port, BS_Pin);

    if (estadoAnterior == 1 && estadoActual == 0) {
        HAL_Delay(50);
        estadoAnterior = 0;
        return 1;
    }
    if (estadoActual == 1) estadoAnterior = 1;

    return 0;
}

void EsperarBotonSoltado(void) {
    while (HAL_GPIO_ReadPin(BS_GPIO_Port, BS_Pin) == GPIO_PIN_RESET) {
        HAL_Delay(10);
    }
}

void ProcesarEntrada(void) {
    int deltaF = xValue_F - CENTER;
    vel_F = (abs(deltaF) > DEADZONE) ? (deltaF * 10) / (MAX_ANALOG - CENTER) : 0;

    int deltaW = xValue_W - CENTER;
    vel_W = (abs(deltaW) > DEADZONE) ? (deltaW * 10) / (MAX_ANALOG - CENTER) : 0;
}

// ============================================================
// Funciones de colisión simplificada
// ============================================================
int BloqueSolido(int x, int y) {
    if (x < 0 || y < 0 || x >= MAP_W * TILE || y >= MAP_H * TILE)
        return 1;
    int tileX = x / TILE;
    int tileY = y / TILE;
    uint8_t t = colisionNivel1[tileY][tileX];
    return (t == 1);
}

int ColisionaRectangulo(int x, int y, int w, int h) {
    return (
        BloqueSolido(x, y) ||
        BloqueSolido(x + w - 1, y) ||
        BloqueSolido(x, y + h - 1) ||
        BloqueSolido(x + w - 1, y + h - 1)
    );
}

// ============================================================
// Movimiento vertical simplificado
// ============================================================
// Variables globales (pueden ir arriba del todo)
int inicioSaltoY_F = 0;
int inicioSaltoY_W = 0;

void MoverVertical(int *x, int *y, int ancho, int alto, int *estado, int *inicioSaltoY, int alturaMax, int velocidad) {
    if (*estado == SALTANDO) {
        for (int i = 0; i < velocidad; i++) {
            int nuevoY = *y - 1;
            if (ColisionaRectangulo(*x, nuevoY, ancho, alto)) {
                *estado = CAYENDO;
                break;
            }
            if (nuevoY <= (*inicioSaltoY - alturaMax)) {
                *estado = CAYENDO;
                break;
            }
            *y = nuevoY;
        }
    } else if (*estado == CAYENDO) {
        for (int i = 0; i < velocidad; i++) {
            int nuevoY = *y + 1;
            if (ColisionaRectangulo(*x, nuevoY, ancho, alto)) {
                *estado = EN_SUELO;
                break;
            }
            *y = nuevoY;
        }
    } else if (*estado == EN_SUELO) {
        if (!ColisionaRectangulo(*x, *y + 1, ancho, alto)) {
            *estado = CAYENDO;
        }
    }
}

// ============================================================
// Movimiento completo de sprites
// ============================================================
void MoverSprites(void) {
    ProcesarEntrada();

    const int anchoF = 16, altoF = 28;
    const int anchoW = 16, altoW = 24;

    static int xF_anterior = 280, yF_anterior = 31;
    static int xW_anterior = 20, yW_anterior = 128;

    if (x_F != xF_anterior || y_F != yF_anterior) {
        SetWindows(xF_anterior, yF_anterior, xF_anterior + anchoF - 1, yF_anterior + altoF - 1);
        if(nivel1SD) LCD_Bitmap(xF_anterior, yF_anterior, anchoF, altoF, &nivel1SD[(yF_anterior * 320 + xF_anterior) * 2]);
    }
    if (x_W != xW_anterior || y_W != yW_anterior) {
        SetWindows(xW_anterior, yW_anterior, xW_anterior + anchoW - 1, yW_anterior + altoW - 1);
        if(nivel1SD) LCD_Bitmap(xW_anterior, yW_anterior, anchoW, altoW, &nivel1SD[(yW_anterior * 320 + xW_anterior) * 2]);
    }

    if (vel_F > 0) direccionF = 1;
    else if (vel_F < 0) direccionF = -1;
    if (vel_W > 0) direccionW = 1;
    else if (vel_W < 0) direccionW = -1;

    int nuevoXF = x_F + vel_F;
    if (!ColisionaRectangulo(nuevoXF, y_F, anchoF, altoF)) x_F = nuevoXF;
    if (saltoF_Trigger && estadoF == EN_SUELO) {
        estadoF = SALTANDO;
        inicioSaltoY_F = y_F;
        saltoF_Trigger = 0;
    }
    MoverVertical(&x_F, &y_F, anchoF, altoF, &estadoF, &inicioSaltoY_F, 18, 5);
    if (estadoF == SALTANDO) LCD_Sprite(x_F, y_F, 15, 20, Fsalto, 1, 0, (vel_F >= 0) ? 0 : 1, 0);
    else if (estadoF == CAYENDO) LCD_Sprite(x_F, y_F, 16, 30, Fcaida, 3, (x_F / 10) % 3, (vel_F >= 0) ? 0 : 1, 0);
    else {
        if (vel_F != 0) LCD_Sprite(x_F, y_F, 22, 21, Fcaminando, 3, (x_F / 10) % 3, (vel_F >= 0) ? 0 : 1, 0);
        else LCD_Bitmap_Transparent(x_F, y_F, anchoF, altoF, Fireboy, 0x0000);
    }

    int nuevoXW = x_W + vel_W;
    if (!ColisionaRectangulo(nuevoXW, y_W, anchoW, altoW)) x_W = nuevoXW;
    if (saltoW_Trigger && estadoW == EN_SUELO) {
        estadoW = SALTANDO;
        inicioSaltoY_W = y_W;
        saltoW_Trigger = 0;
    }
    MoverVertical(&x_W, &y_W, anchoW, altoW, &estadoW, &inicioSaltoY_W, 18, 5);
    if (estadoW == SALTANDO) LCD_Sprite(x_W, y_W, 16, 24, Wsalto, 1, 0, (vel_W >= 0) ? 0 : 1, 0);
    else if (estadoW == CAYENDO) LCD_Sprite(x_W, y_W, 20, 37, Wcaida, 3, (x_W / 10) % 3, (vel_W >= 0) ? 0 : 1, 0);
    else {
        if (vel_W != 0) LCD_Sprite(x_W, y_W, 28, 24, Wcaminando, 3, (x_W / 10) % 3, (vel_W >= 0) ? 0 : 1, 0);
        else LCD_Bitmap_Transparent(x_W, y_W, anchoW, altoW, Watergirl, 0x0000);
    }

    DibujarDiamantes();
    VerificarRecoleccion();
    VerificarMuerte();
    VerificarFinal();

    xF_anterior = x_F;
    yF_anterior = y_F;
    xW_anterior = x_W;
    yW_anterior = y_W;
}

/* CALLBACK UART4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    // Código idéntico al original
    if (huart->Instance == UART4) {
        if (rxByte != '\n' && uartIndex < sizeof(uartBuffer) - 1) {
            uartBuffer[uartIndex++] = rxByte;
        } else {
            uartBuffer[uartIndex] = '\0';
            uartIndex = 0;
            char emisor[5];
            int xVal, boton;
            if (sscanf(uartBuffer, "[%4[^]]] X: %d | Botón: %d", emisor, &xVal, &boton) == 3) {
                static uint8_t botonF_Ant = 0;
                static uint8_t botonW_Ant = 0;
                if (strcmp(emisor, "ESP1") == 0) {
                    xValue_F = xVal;
                    if (pantalla_actual != PANTALLA_NIVEL1) {
                        if (boton == 1 && !botonF_Ant) {
                            if (pantalla_actual == PANTALLA_MENU) pantalla_actual = PANTALLA_NIVELES;
                            else if (pantalla_actual == PANTALLA_NIVELES) pantalla_actual = PANTALLA_NIVEL1;
                        }
                    } else {
                        if (boton == 1 && !botonF_Ant) saltoF_Trigger = 1;
                    }
                    botonF_Ant = boton;
                }
                if (strcmp(emisor, "ESP2") == 0) {
                    xValue_W = xVal;
                    if (pantalla_actual != PANTALLA_NIVEL1) {
                        if (boton == 1 && !botonW_Ant) {
                            if (pantalla_actual == PANTALLA_MENU) pantalla_actual = PANTALLA_NIVELES;
                            else if (pantalla_actual == PANTALLA_NIVELES) pantalla_actual = PANTALLA_NIVEL1;
                        }
                    } else {
                        if (boton == 1 && !botonW_Ant) saltoW_Trigger = 1;
                    }
                    botonW_Ant = boton;
                }
                strcpy(datosRecibidos.emisorID, emisor);
                datosRecibidos.xValue = (strcmp(emisor, "ESP1") == 0) ? xValue_F : xValue_W;
                datosRecibidos.botonState = boton;
            }

            HAL_UART_Transmit(&huart2, (uint8_t *)uartBuffer, strlen(uartBuffer), HAL_MAX_DELAY);
            HAL_UART_Transmit(&huart2, (uint8_t *)"\r\n", 2, HAL_MAX_DELAY);
        }
        HAL_UART_Receive_IT(&huart4, &rxByte, 1);
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  MX_UART4_Init();
  MX_FATFS_Init();

  /* USER CODE BEGIN 2 */
  LCD_Init();
  LCD_Clear(0x0000);

  EnviarMensaje("Sistema iniciado correctamente\r\n");

  HAL_UART_Receive_IT(&huart4, &rxByte, 1);

  // =========================
  // CARGA DE FONDOS DESDE SD
  // =========================
  #define WIDTH  320
  #define HEIGHT 240
  #define IMG_SIZE (WIDTH*HEIGHT*2)  // 2 bytes por píxel

  fondoSD   = CargarImagenSD("fondo.raw", IMG_SIZE);
  nivelesSD = CargarImagenSD("niveles.raw", IMG_SIZE);
  nivel1SD  = CargarImagenSD("nivel1.raw", IMG_SIZE);
  finalSD   = CargarImagenSD("final.raw", IMG_SIZE);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      switch(pantalla_actual) {
          case PANTALLA_MENU:
              if(fondoSD) LCD_Bitmap(0, 0, 320, 240, fondoSD);
              break;
          case PANTALLA_NIVELES:
              if(nivelesSD) LCD_Bitmap(0, 0, 320, 240, nivelesSD);
              break;
          case PANTALLA_NIVEL1:
              if(nivel1SD) LCD_Bitmap(0, 0, 320, 240, nivel1SD);
              LCD_Bitmap_Transparent(x_W, y_W, 16, 24, Watergirl, 0x0000);
              LCD_Bitmap_Transparent(x_F, y_F, 16, 28, Fireboy, 0x0000);
              DibujarDiamantes();
              break;
          default:
              break;
      }

      MoverSprites();
      HAL_Delay(16); // ~60fps
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_SS_GPIO_Port, SD_SS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : BS_Pin */
  GPIO_InitStruct.Pin = BS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_SS_Pin */
  GPIO_InitStruct.Pin = SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(SD_SS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* ============================================================
 *  FUNCIONES DE COLISIÓN Y JUEGO
 * ============================================================ */

// devuelve el tipo de tile en la coordenada de píxel (x,y)
// devuelve 0 si está fuera del mapa (espacio vacío)
int TileTipoEnPixel(int x, int y) {
    int tx = x / TILE;
    int ty = y / TILE;
    if (tx < 0 || tx >= MAP_W || ty < 0 || ty >= MAP_H)
        return 0; // fuera -> vacío (no matar ni considerar bloque)
    return colisionNivel1[ty][tx];
}

void VerificarMuerte(void) {
    const int anchoF = 16, altoF = 28;
    const int anchoW = 16, altoW = 24;

    // ---- FIREBOY ----
    // Revisar debajo y al frente
    int tipoF_pies = TileTipoEnPixel(x_F + anchoF / 2, y_F + altoF - 2);
    int tipoF_frente = TileTipoEnPixel(
        x_F + (direccionF > 0 ? anchoF - 1 : 0),   // si mira a la derecha o izquierda
        y_F + altoF / 2                           // a la mitad del cuerpo
    );

    if ((tipoF_pies == 3 && y_F + altoF >= (y_F / TILE + 1) * TILE - 2) || tipoF_frente == 3) {  // si toca o está frente al agua
        EnviarMensaje("🔥 Fireboy murio (agua)\r\n");
        x_F = 280;
        y_F = 31.5;
        vel_F = 0;
        estadoF = EN_SUELO;
        HAL_Delay(500);
        SetWindows(0, 0, 319, 239);
        LCD_Bitmap(0, 0, 320, 240, nivel1SD);
        DibujarDiamantes();
    }

    // ---- WATERGIRL ----
    int tipoW_pies = TileTipoEnPixel(x_W + anchoW / 2, y_W + altoW - 1);
    int tipoW_frente = TileTipoEnPixel(
        x_W + (direccionW > 0 ? anchoW - 1 : 0),
        y_W + altoW / 2
    );

    if ((tipoW_pies == 2 && y_W + altoW >= (y_W / TILE + 1) * TILE - 2) || tipoW_frente == 2) {  // si toca o está frente a lava
        EnviarMensaje("💧 Watergirl murio (lava)\r\n");
        x_W = 20;
        y_W = 115;
        vel_W = 0;
        estadoW = EN_SUELO;
        HAL_Delay(500);
        SetWindows(0, 0, 319, 239);
        LCD_Bitmap(0, 0, 320, 240, nivel1SD);
        DibujarDiamantes();
    }
}

// ============================================================
// FUNCIÓN PARA DETECTAR SI AMBOS ESTÁN EN SUS ZONAS FINALES
// ============================================================
void VerificarFinal(void) {
    if (pantalla_actual != PANTALLA_NIVEL1) return;

    // Convertir coordenadas a columnas y filas del mapa
    int col_F = x_F / TILE;
    int fila_F = y_F / TILE;
    int col_W = x_W / TILE;
    int fila_W = y_W / TILE;

    // 🔹 Fireboy: entre columnas 2 y 6 (derecha a izquierda) y filas 15 y 14
    int fireboy_en_rango = (col_F >= 2 && col_F <= 6 && fila_F >= 14 && fila_F <= 15);

    // 🔹 Watergirl: entre columnas 7 y 9 (izquierda a derecha) y filas 26 a 28
    int watergirl_en_rango = (col_W >= 7 && col_W <= 9 && fila_W >= 26 && fila_W <= 28);

    // Si ambos están en sus rangos → mostrar pantalla final
    if (fireboy_en_rango && watergirl_en_rango) {
        pantalla_actual = PANTALLA_MENU; // o puedes crear PANTALLA_FINAL si prefieres
        LCD_Bitmap(0, 0, 320, 240, finalSD);
        EnviarMensaje("🎉 Nivel completado: ambos llegaron a su salida\r\n");
        HAL_Delay(2000);
    }
}


void DibujarDiamantes(void) {
    for (int i = 0; i < NUM_DIAMANTES; i++) {
        if (diamantes[i].activo) {
            if (diamantes[i].tipo == 1)
                LCD_Bitmap_Transparent(diamantes[i].x, diamantes[i].y, 15, 12, fuegoD, 0x0000);
            else
                LCD_Bitmap_Transparent(diamantes[i].x, diamantes[i].y, 15, 12, aguaD, 0x0000);
        }
    }
}

void VerificarRecoleccion(void) {
    for (int i = 0; i < NUM_DIAMANTES; i++) {
        if (diamantes[i].activo) {
            if (diamantes[i].tipo == 1 &&
                abs(x_F - diamantes[i].x) < 10 &&
                abs(y_F - diamantes[i].y) < 10) {
                diamantes[i].activo = 0;
                EnviarMensaje("🔥 Diamante de fuego recogido\r\n");
                SetWindows(diamantes[i].x, diamantes[i].y, diamantes[i].x + 15 - 1, diamantes[i].y + 12 - 1);
                LCD_Bitmap(diamantes[i].x, diamantes[i].y, 15, 12, &nivel1SD[(diamantes[i].y * 320 + diamantes[i].x) * 2]);

            }
            if (diamantes[i].tipo == 0 &&
                abs(x_W - diamantes[i].x) < 10 &&
                abs(y_W - diamantes[i].y) < 10) {
                diamantes[i].activo = 0;
                EnviarMensaje("💧 Diamante de agua recogido\r\n");
                SetWindows(diamantes[i].x, diamantes[i].y, diamantes[i].x + 15 - 1, diamantes[i].y + 12 - 1);
                LCD_Bitmap(diamantes[i].x, diamantes[i].y, 15, 12, &nivel1SD[(diamantes[i].y * 320 + diamantes[i].x) * 2]);

            }
        }
    }
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	__disable_irq();
	while (1) {}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */