/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ili9341.h"
#include "Bitmaps.h"
#include <stdio.h>
#include "Neopixel.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim4;
DMA_HandleTypeDef hdma_tim4_ch2;

/* USER CODE BEGIN PV */
uint16_t adcValue = 0;
uint16_t adcFiltered = 0;  // valor filtrado
float alpha = 0.2;        // suavizado (0.1 a 0.3)

uint16_t threshold = 1200; // ajustalo segun sensor
int slotState = 0;         // 0 = libre, 1 = ocupado

float brilloled = 100;


uint8_t aTxBuffer[1];  // para enviar al maestro
uint8_t aRxBuffer[1];  // para recibir del maestro

// Estados de los 8 slots
uint8_t state_local[4];   // tus 4 sensores (slots 5-8)
uint8_t state_remote[4];  // los 4 del otro Nucleo (slots 1-4)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM4_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void DrawSegment(int x, int y, int w, int h, uint16_t color) {
    FillRect(x, y, w, h, color);
}

void Draw7SegDigit(int x, int y, int num, uint16_t colorON, uint16_t colorOFF) {

    int segW = 40; // ancho del segmento horizontal
    int segH = 6;  // alto del segmento horizontal
    int segV_W = 6; // ancho segmento vertical
    int segV_H = 40;

    // Coordenadas de cada segmento a,b,c,d,e,f,g
    int ax = x + 10, ay = y;
    int fx = x,     fy = y + 5;
    int bx = x + 50, by = y + 5;
    int gx = x + 10, gy = y + 45;
    int ex = x,     ey = y + 50;
    int cx = x + 50, cy = y + 50;
    int dx = x + 10, dy = y + 90;

    // Tabla de segmentos para 0-9
    int seg[10][7] = {
        {1,1,1,1,1,1,0}, // 0
        {0,1,1,0,0,0,0}, // 1
        {1,1,0,1,1,0,1}, // 2
        {1,1,1,1,0,0,1}, // 3
        {0,1,1,0,0,1,1}, // 4
        {1,0,1,1,0,1,1}, // 5
        {1,0,1,1,1,1,1}, // 6
        {1,1,1,0,0,0,0}, // 7
        {1,1,1,1,1,1,1}, // 8
        {1,1,1,1,0,1,1}  // 9
    };

    // Dibujar cada segmento
    DrawSegment(ax, ay, segW, segH, seg[num][0] ? colorON : colorOFF); // a
    DrawSegment(fx, fy, segV_W, segV_H, seg[num][5] ? colorON : colorOFF); // f
    DrawSegment(bx, by, segV_W, segV_H, seg[num][1] ? colorON : colorOFF); // b
    DrawSegment(gx, gy, segW, segH, seg[num][6] ? colorON : colorOFF); // g
    DrawSegment(ex, ey, segV_W, segV_H, seg[num][4] ? colorON : colorOFF); // e
    DrawSegment(cx, cy, segV_W, segV_H, seg[num][2] ? colorON : colorOFF); // c
    DrawSegment(dx, dy, segW, segH, seg[num][3] ? colorON : colorOFF); // d
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_TIM4_Init();
  MX_I2C1_Init();

  // === Habilitar modo escucha esclavo ===
  HAL_I2C_EnableListen_IT(&hi2c1);
  HAL_I2C_Slave_Receive_IT(&hi2c1, aRxBuffer, 1);
  /* USER CODE BEGIN 2 */

	LCD_Init();

	LCD_Clear(0xFFFF);  // Blanco

	pixelClear();
	setBrightness(80);   // brillo inicial
	pixelShow();

	// ===== Colores =====
	uint16_t gris       = 0xD6BA;
	uint16_t gris_claro = 0xF7DE;
	uint16_t amarillo   = 0xFCE0;
	uint16_t negro      = 0x0000;
	//uint16_t rojo       = 0xF800;
	//uint16_t verde      = 0x07E0;
	//uint16_t azul       = 0x001F;

	// Fondo general
	FillRect(0, 0, 320, 240, gris_claro);

	// Título
	LCD_Print("Parqueo-matic", 60, 5, 2, negro, gris_claro);

	// === Dimensiones ===
	int slotW = 45;
	int slotH = 80;
	int startX = 10;
	int startY = 30;
	int gap   = 6;

	// ==== Dibujar 2 filas x 4 columnas ====
	for(int row = 0; row < 2; row++)
	{
	    for(int col = 0; col < 4; col++)
	    {
	        int x = startX + col * (slotW + gap);
	        int y = startY + row * (slotH + 40);

	        // Piso
	        FillRect(x, y, slotW, slotH, gris);

	        // Líneas amarillas laterales
	        FillRect(x, y, 5, slotH, amarillo);
	        FillRect(x + slotW - 5, y, 5, slotH, amarillo);

	        // ==== Ubicar indicadores según fila ====
	        int sensorY;
	        if(row == 0)
	        {
	            // Fila de ARRIBA -> sensores abajo
	            sensorY = y + slotH + 5;
	        }
	        else
	        {
	            // Fila de ABAJO -> sensores ARRIBA
	            sensorY = y - 15;
	        }

	        // Caja del indicador
	        FillRect(x + slotW/2 - 12, sensorY, 24, 12, 0xFFFF);

	        // Colores dinámicos
	        //uint16_t rojo_ON   = 0xF800; // rojo brillante
	        //uint16_t rojo_OFF  = 0x4000; // rojo MUY pálido, casi apagado
	        //uint16_t verde_ON  = 0x07E0; // verde brillante
	        //uint16_t verde_OFF = 0x02E0; // verde pálido

	    }
	}

	// === Dibujar autos en los slots ===
	int carW = 30; // más pequeño
	int carH = 60; // más pequeño
	uint16_t carColor    = 0x780F;  // morado
	uint16_t windowColor = 0x7FFF;  // celeste
	uint16_t tireColor   = negro;

	for(int row = 0; row < 2; row++)
	{
	    for(int col = 0; col < 4; col++)
	    {
	        int x = startX + col * (slotW + gap);
	        int y = startY + row * (slotH + 40);

	        // Centro del carro dentro del slot dejando márgenes visibles
	        int cx = x + (slotW - carW) / 2;
	        int cy = y + (slotH - carH) / 2;

	        // ==== Dibujo del auto ====

	        // Carrocería
	        FillRect(cx, cy, carW, carH, carColor);

	        // Techo del carro
	        FillRect(cx + 4, cy + 12, carW - 8, carH - 24, 0xA93F); // beige

	        // Ventanas
	        FillRect(cx + 6, cy + 14, carW - 12, 12, windowColor);
	        FillRect(cx + 6, cy + carH - 26, carW - 12, 12, windowColor);

	        // Llantas (más pequeñas y dentro del slot)
	        FillRect(cx - 2, cy + 6, 4, 16, tireColor);
	        FillRect(cx - 2, cy + carH - 22, 4, 16, tireColor);
	        FillRect(cx + carW - 2, cy + 6, 4, 16, tireColor);
	        FillRect(cx + carW - 2, cy + carH - 22, 4, 16, tireColor);
	    }
	}

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {

		/////// === LECTURA DIGITAL DE MÓDULOS IR === ///////

		int state[4];

		// Leer los pines directamente
		state[0] = (HAL_GPIO_ReadPin(GPIOC, Sensor1_Pin) == GPIO_PIN_RESET) ? 1 : 0;  // 1 = ocupado
		state[1] = (HAL_GPIO_ReadPin(GPIOC, Sensor2_Pin) == GPIO_PIN_RESET) ? 1 : 0;
		state[2] = (HAL_GPIO_ReadPin(GPIOC, Sensor3_Pin) == GPIO_PIN_RESET) ? 1 : 0;
		state[3] = (HAL_GPIO_ReadPin(GPIOC, Sensor4_Pin) == GPIO_PIN_RESET) ? 1 : 0;

        /////// === COMBINAR ESTADOS LOCALES Y REMOTOS === ///////
        // Copiar tus sensores locales (slots 5–8)
        int state_local[4];
        for (int i = 0; i < 4; i++) state_local[i] = state[i];

        // Crear un arreglo con los 8 slots totales
        // Los primeros 4 serán los de tu compañera (recibidos por I2C)
        // y los últimos 4 serán los tuyos (leídos localmente)
        int fullState[8];
        for (int i = 0; i < 4; i++) fullState[i] = state_remote[i];  // los 4 remotos (de ella)
        for (int i = 0; i < 4; i++) fullState[i + 4] = state_local[i]; // tus 4 locales


		/////// === COLORES === ///////
		//uint16_t rojo_ON   = 0xF800;
		//uint16_t rojo_OFF  = 0xC880;
		//uint16_t verde_ON  = 0x07E0;
		//uint16_t verde_OFF = 0xAEEA;

		/////// === DIBUJAR LOS 8 SLOTS === ///////
		for (int i = 0; i < 8; i++) {
		    int row = (i < 4) ? 0 : 1;           // primera o segunda fila
		    int col = (i % 4);                   // columna dentro de la fila
		    int x = startX + col * (slotW + gap);
		    int y = startY + row * (slotH + 40);
		    int cx = x + (slotW - carW) / 2;
		    int cy = y + (slotH - carH) / 2;

		    // ==== AUTO ====
		    if (fullState[i] == 1) { // ocupado
		        FillRect(cx, cy, carW, carH, 0x780F);
		        FillRect(cx + 4, cy + 12, carW - 8, carH - 24, 0xA93F);
		        FillRect(cx + 6, cy + 14, carW - 12, 12, 0x7FFF);
		        FillRect(cx + 6, cy + carH - 26, carW - 12, 12, 0x7FFF);
		        FillRect(cx - 2, cy + 6, 4, 16, 0x0000);
		        FillRect(cx - 2, cy + carH - 22, 4, 16, 0x0000);
		        FillRect(cx + carW - 2, cy + 6, 4, 16, 0x0000);
		        FillRect(cx + carW - 2, cy + carH - 22, 4, 16, 0x0000);
		    } else { // libre
		        FillRect(cx, cy, carW, carH, 0xD6BA);
		    }

		    // ==== LEDs ====
		    int ledX = x + slotW/2 - 12;
		    int ledY = (row == 0) ? (y + slotH + 5) : (y - 15);
		    FillRect(ledX, ledY, 24, 12, 0xFFFF);
		    FillRect(ledX + 2,  ledY + 2, 8, 8, fullState[i] ? 0xF800 : 0xC880);
		    FillRect(ledX + 14, ledY + 2, 8, 8, fullState[i] ? 0xAEEA : 0x07E0);
		}


		/////// === DISPLAY DE ESPACIOS DISPONIBLES === ///////
		int libres = 0;
		for (int i = 0; i < 8; i++)
		    if (fullState[i] == 0) libres++;

		int dispX = 240;
		int dispY = 70;
		FillRect(dispX, dispY, 60, 90, 0xFFFF);
		Draw7SegDigit(dispX + 8, dispY + 5, (libres > 9 ? 9 : libres), 0xF800, 0xD6BA);


		/////// === ACTUALIZAR NEOPIXELS === ///////
		pixelClear();           // limpia todos los LEDs

		// --- SLOT 1 ---
		if (state[0] == 1) {
		    // Ocupado → rojo
		    setPixelColor(0, 255, 0, 30);
		} else {
		    // Libre → verde
		    setPixelColor(0, 0, 255, 0);
		}

		// --- SLOT 2 ---
		if (state[1] == 1) {
		    // Ocupado → rojo más real
		    setPixelColor(1, 255, 0, 30);
		} else {
		    // Libre → verde
		    setPixelColor(1, 0, 255, 0);
		}

		// --- SLOT 3 ---
		if (state[2] == 1) {
			// Ocupado → rojo más real
			setPixelColor(2, 255, 0, 30);
		} else {
			// Libre → verde
			setPixelColor(2, 0, 255, 0);
		}

		// --- SLOT 4 ---
		if (state[3] == 1) {
			// Ocupado → rojo más real
			setPixelColor(3, 255, 0, 30);
		} else {
			// Libre → verde
			setPixelColor(3, 0, 255, 0);
		}

		setBrightness(60);
		pixelShow();
		HAL_Delay(1); // breve pausa para estabilidad


		HAL_Delay(100);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 170;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 104;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_DISABLE_OCxPRELOAD(&htim4, TIM_CHANNEL_2);
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Sensor1_Pin Sensor2_Pin Sensor3_Pin Sensor4_Pin */
  GPIO_InitStruct.Pin = Sensor1_Pin|Sensor2_Pin|Sensor3_Pin|Sensor4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin SD_SS_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// ============================================================
// === CALLBACKS I2C PARA COMPATIBILIDAD CON NUCLEO DE ELLA ===
// ============================================================

// Reiniciar escucha
void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c) {
    HAL_I2C_EnableListen_IT(hi2c);
}

// ------------------------------------------------------------
// Enviar datos (cuando el ESP32 nos lee)
// ------------------------------------------------------------
void HAL_I2C_SlaveTxCpltCallback(I2C_HandleTypeDef *I2cHandle) {

    // === 1. Inicializa el buffer para evitar valores basura ===
    aTxBuffer[0] = 0;

    // === 2. Leer los sensores locales (5–8) ===
    // Los módulos FC-51 entregan 0 (LOW) cuando detectan algo
    uint8_t S5 = (HAL_GPIO_ReadPin(GPIOC, Sensor1_Pin) == GPIO_PIN_RESET) ? 1 : 0;
    uint8_t S6 = (HAL_GPIO_ReadPin(GPIOC, Sensor2_Pin) == GPIO_PIN_RESET) ? 1 : 0;
    uint8_t S7 = (HAL_GPIO_ReadPin(GPIOC, Sensor3_Pin) == GPIO_PIN_RESET) ? 1 : 0;
    uint8_t S8 = (HAL_GPIO_ReadPin(GPIOC, Sensor4_Pin) == GPIO_PIN_RESET) ? 1 : 0;

    // === 3. Codificar igual que la Nucleo de tu compañera ===
    // (0x00 → todos libres, 0x0F → todos ocupados)
    if (S5==1 && S6==1 && S7==1 && S8==1) aTxBuffer[0] = 0;
    else if (S5==0 && S6==1 && S7==1 && S8==1) aTxBuffer[0] = 1;
    else if (S5==1 && S6==0 && S7==1 && S8==1) aTxBuffer[0] = 2;
    else if (S5==0 && S6==0 && S7==1 && S8==1) aTxBuffer[0] = 3;
    else if (S5==1 && S6==1 && S7==0 && S8==1) aTxBuffer[0] = 4;
    else if (S5==0 && S6==1 && S7==0 && S8==1) aTxBuffer[0] = 5;
    else if (S5==1 && S6==0 && S7==0 && S8==1) aTxBuffer[0] = 6;
    else if (S5==0 && S6==0 && S7==0 && S8==1) aTxBuffer[0] = 7;
    else if (S5==1 && S6==1 && S7==1 && S8==0) aTxBuffer[0] = 8;
    else if (S5==0 && S6==1 && S7==1 && S8==0) aTxBuffer[0] = 9;
    else if (S5==1 && S6==0 && S7==1 && S8==0) aTxBuffer[0] = 10;
    else if (S5==0 && S6==0 && S7==1 && S8==0) aTxBuffer[0] = 11;
    else if (S5==1 && S6==1 && S7==0 && S8==0) aTxBuffer[0] = 12;
    else if (S5==0 && S6==1 && S7==0 && S8==0) aTxBuffer[0] = 13;
    else if (S5==1 && S6==0 && S7==0 && S8==0) aTxBuffer[0] = 14;
    else if (S5==0 && S6==0 && S7==0 && S8==0) aTxBuffer[0] = 15;
    else aTxBuffer[0] = 0x0F;  // valor de respaldo si algo sale fuera de rango

    // === 4. (opcional) Debug por UART o SWO ===
    // printf("Valor enviado I2C: %d\r\n", aTxBuffer[0]);

    // === 5. Transmitir el byte al ESP32 ===
    HAL_I2C_Slave_Transmit_IT(I2cHandle, aTxBuffer, 1);
}


// ------------------------------------------------------------
// Recibir datos (cuando el ESP32 nos escribe)
// ------------------------------------------------------------
void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *I2cHandle) {
    uint8_t v = aRxBuffer[0];

    // === Decodificar igual que la de tu compañera ===
    if (v == 0)      { state_remote[0]=1; state_remote[1]=1; state_remote[2]=1; state_remote[3]=1; }
    else if (v == 1) { state_remote[0]=0; state_remote[1]=1; state_remote[2]=1; state_remote[3]=1; }
    else if (v == 2) { state_remote[0]=1; state_remote[1]=0; state_remote[2]=1; state_remote[3]=1; }
    else if (v == 3) { state_remote[0]=0; state_remote[1]=0; state_remote[2]=1; state_remote[3]=1; }
    else if (v == 4) { state_remote[0]=1; state_remote[1]=1; state_remote[2]=0; state_remote[3]=1; }
    else if (v == 5) { state_remote[0]=0; state_remote[1]=1; state_remote[2]=0; state_remote[3]=1; }
    else if (v == 6) { state_remote[0]=1; state_remote[1]=0; state_remote[2]=0; state_remote[3]=1; }
    else if (v == 7) { state_remote[0]=0; state_remote[1]=0; state_remote[2]=0; state_remote[3]=1; }
    else if (v == 8) { state_remote[0]=1; state_remote[1]=1; state_remote[2]=1; state_remote[3]=0; }
    else if (v == 9) { state_remote[0]=0; state_remote[1]=1; state_remote[2]=1; state_remote[3]=0; }
    else if (v == 10){ state_remote[0]=1; state_remote[1]=0; state_remote[2]=1; state_remote[3]=0; }
    else if (v == 11){ state_remote[0]=0; state_remote[1]=0; state_remote[2]=1; state_remote[3]=0; }
    else if (v == 12){ state_remote[0]=1; state_remote[1]=1; state_remote[2]=0; state_remote[3]=0; }
    else if (v == 13){ state_remote[0]=0; state_remote[1]=1; state_remote[2]=0; state_remote[3]=0; }
    else if (v == 14){ state_remote[0]=1; state_remote[1]=0; state_remote[2]=0; state_remote[3]=0; }
    else if (v == 15){ state_remote[0]=0; state_remote[1]=0; state_remote[2]=0; state_remote[3]=0; }
    else             { state_remote[0]=1; state_remote[1]=1; state_remote[2]=1; state_remote[3]=1; }

    HAL_I2C_Slave_Receive_IT(I2cHandle, aRxBuffer, 1);
}

// ------------------------------------------------------------
// Dirección detectada
// ------------------------------------------------------------
void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection, uint16_t AddrMatchCode) {
    if (TransferDirection == I2C_DIRECTION_TRANSMIT) {
        HAL_I2C_Slave_Seq_Receive_IT(&hi2c1, aRxBuffer, 1, I2C_FIRST_AND_LAST_FRAME);
    } else if (TransferDirection == I2C_DIRECTION_RECEIVE) {
        HAL_I2C_Slave_Seq_Transmit_IT(&hi2c1, aTxBuffer, 1, I2C_FIRST_AND_LAST_FRAME);
    }
}

// ------------------------------------------------------------
// Error callback
// ------------------------------------------------------------
void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *I2CHandle) {
    if (HAL_I2C_GetError(I2CHandle) != HAL_I2C_ERROR_AF) {
        Error_Handler();
    }
}

/* USER CODE END 4 */


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
