/*
 * LAB 6 - ARDUINO NANO.c
 *
 * Created: 11/09/2025 10:55:39
 * Author : Luis Sactic
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h> 

/* ===================== UART ===================== */
#define BAUD 9600UL
#define UBRRVAL ((F_CPU/16/BAUD)-1)

void UART_init(void) {
    UBRR0H = (uint8_t)(UBRRVAL >> 8);
    UBRR0L = (uint8_t)(UBRRVAL);
    UCSR0B = (1<<RXEN0) | (1<<TXEN0);
    UCSR0C = (1<<UCSZ01) | (1<<UCSZ00);
}

void UART_send(uint8_t c) {
    while (!(UCSR0A & (1<<UDRE0)));
    UDR0 = c;
}

/* ============ Configuraci�n de botones ============ */
#define BTN_MASK ((1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7))

// Caracteres para cada bot�n (PD2, PD3, PD4, PD5, PD6, PD7)
const char BTN_CHARS[] = {'U','D','R','L','A','B'};

// Variables para antirrebote
volatile uint8_t debounce_counters[6] = {0};
volatile uint8_t stable_states[6] = {0};
volatile uint8_t button_events = 0;
volatile uint8_t last_portd_state;

/* ============ Inicializaciones ============ */
void buttons_init(void) {
    // Configurar pines como entradas con pull-up
    DDRD &= ~BTN_MASK;   // Todos como entradas
    PORTD |= BTN_MASK;   // Activar pull-ups
    
    // Leer estado inicial de los botones
    last_portd_state = PIND;
    for(uint8_t i=0; i<6; i++) {
        stable_states[i] = (PIND & (1<<(PD2+i))) ? 0 : 1;
    }
    
    // Habilitar interrupciones por cambio en PORTD
    PCICR |= (1<<PCIE2);
    PCMSK2 |= BTN_MASK;
}

void timer1_init(void) {
    // Timer1 a 1kHz para antirrebote
    TCCR1A = 0;
    TCCR1B = (1<<WGM12) | (1<<CS11) | (1<<CS10); // CTC, prescaler 64
    OCR1A = 249; // 16MHz/64/250 = 1kHz
    TIMSK1 = (1<<OCIE1A);
}

/* ============ Interrupciones ============ */
ISR(PCINT2_vect) {
    uint8_t current = PIND;
    uint8_t changes = current ^ last_portd_state;
    last_portd_state = current;
    
    for(uint8_t i=0; i<6; i++) {
        if(changes & (1<<(PD2+i))) {
            debounce_counters[i] = 20; // 20ms de antirrebote
        }
    }
}

ISR(TIMER1_COMPA_vect) {
    for(uint8_t i=0; i<6; i++) {
        if(debounce_counters[i] > 0) {
            debounce_counters[i]--;
            if(debounce_counters[i] == 0) {
                uint8_t pressed = (PIND & (1<<(PD2+i))) ? 0 : 1;
                if(pressed && !stable_states[i]) {
                    button_events |= (1<<i);
                }
                stable_states[i] = pressed;
            }
        }
    }
}

/* ============ Main ============ */
int main(void) {
    UART_init();
    buttons_init();
    timer1_init();
    sei();
    
    while(1) {
        if(button_events) {
            for(uint8_t i=0; i<6; i++) {
                if(button_events & (1<<i)) {
                    UART_send(BTN_CHARS[i]);
                }
            }
            button_events = 0;
        }
    }
}