/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;   // Terminal PC: PA2/PA3
UART_HandleTypeDef huart3;   // Arduino Nano AVR:   PB10/PC5

/* USER CODE BEGIN PV */
/* Variables de estado del sistema */
volatile uint8_t dato_rx = 0;           /* byte recibido desde USART3 */
volatile uint8_t dato_estable = 0;      /* ultimo dato valido recibido */
char texto_salida[30] = "Ultimo: Ninguno\r\n";   /* mensaje enviado a la terminal */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);

/* USER CODE BEGIN PFP */
static const char* obtener_mensaje(uint8_t caracter);
static void LimpiarBufferUART3(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
/**
  * @brief  Obtiene el mensaje correspondiente al caracter recibido
  * @param  caracter: Caracter recibido del microcontrolador AVR
  * @retval Cadena de texto con la accion correspondiente
  */
static const char* obtener_mensaje(uint8_t caracter) {
  switch (caracter) {
    case 'U': return "Arriba";
    case 'D': return "Abajo";
    case 'L': return "Izquierda";
    case 'R': return "Derecha";
    case 'A': return "Boton A";
    case 'B': return "Boton B";
    default:  return "Desconocido";
  }
}
/* USER CODE END 0 */

/**
  * @brief  Punto de inicio de la aplicacion
  * @retval int
  */
int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();

  /* USER CODE BEGIN 2 */
  /* Iniciar recepcion por interrupcion desde el AVR */
  HAL_UART_Receive_IT(&huart3, (uint8_t*)&dato_rx, 1);
  /* USER CODE END 2 */

  while (1)
  {
    /* Procesamiento mediante interrupciones */
  }
}

/**
  * @brief Configuracion del reloj del sistema
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /* Configuracion HSI + PLL a 84 MHz */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;  // 42 MHz
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;  // 84 MHz

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief Inicializacion USART2 (Comunicacion con PC)
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief Inicializacion USART3 (Comunicacion con AVR)
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK) {
    Error_Handler();
  }
}

/**
  * @brief Inicializacion de GPIO
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* Estado inicial LED apagado */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /* Configuracion boton usuario */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /* Configuracion LED de estado */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/**
  * @brief  Limpia el buffer de recepcion del UART3
  */
static void LimpiarBufferUART3(void) {
  while (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_RXNE)) {
    volatile uint8_t temporal = (uint8_t)(huart3.Instance->DR & 0xFF);
    (void)temporal;
  }
}

/**
  * @brief  Callback de recepcion UART
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3) {
    if (dato_rx >= 'A' && dato_rx <= 'Z') {
        dato_estable = dato_rx;

        /* Borrar línea anterior y mostrar nueva */
        char mensaje_actual[30];
        snprintf(mensaje_actual, sizeof(mensaje_actual), "\rUltimo: %s        \r\n", obtener_mensaje(dato_rx));

        /* Copiar para Live Expressions */
        strncpy(texto_salida, mensaje_actual, sizeof(texto_salida)-1);
        texto_salida[sizeof(texto_salida)-1] = '\0';

        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
        HAL_UART_Transmit(&huart2, (uint8_t*)mensaje_actual, strlen(mensaje_actual), HAL_MAX_DELAY);
    }

    LimpiarBufferUART3();
    HAL_UART_Receive_IT(&huart3, (uint8_t*)&dato_rx, 1);
  }
}
/**
  * @brief  Callback de error UART
  */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3) {
    /* Limpieza en caso de error */
    LimpiarBufferUART3();
    HAL_UART_Receive_IT(&huart3, (uint8_t*)&dato_rx, 1);
  }
}
/* USER CODE END 4 */

/**
  * @brief  Manejador de errores del sistema
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  (void)file; (void)line;
}
#endif /* USE_FULL_ASSERT */
